import React from 'react';

export default function Dashboard() {
  return (
    <div>
      <h2>Dashboard</h2>
      <p>This is where your section cards will go.</p>
    </div>
  );
}
